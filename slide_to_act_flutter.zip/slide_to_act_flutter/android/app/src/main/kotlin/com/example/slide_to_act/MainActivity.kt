package com.example.slide_to_act

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
